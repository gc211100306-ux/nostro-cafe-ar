NOSTRO CAFÉ — EXPERIENCIA AR
=============================

Contenido:
- index.html: página de la experiencia.
- assets/nostro_cafe_producto.png: referencia visual del producto.
- models/: coloca aquí los modelos 3D finales:
    nostro_cafe_bourbon.glb
    nostro_cafe_bourbon.usdz (opcional para iPhone/iPad)

IMPORTANTE:
Esta página está preparada para mostrar un modelo 3D y activar AR.
Para que el botón AR funcione, necesitas subir un archivo GLB válido a
models/nostro_cafe_bourbon.glb (y opcionalmente USDZ).

PUBLICACIÓN GRATUITA:
Puedes subir esta carpeta a un hosting estático que permita HTTPS, por
ejemplo GitHub Pages, Netlify o Vercel. Después usa la URL pública para
generar el QR.

NOTA:
El archivo de referencia PNG no es un modelo 3D. Se incluye para conservar
la referencia visual de la bolsa/producto de Nostro Café.
